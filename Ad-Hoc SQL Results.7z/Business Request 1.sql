WITH MonthlyCirculationChange AS (
    SELECT
        f.City_ID,
        d.city AS city_name,
        STR_TO_DATE(f.Month, '%b-%y') AS month_date,
        f.Net_Circulation,
        LAG(f.Net_Circulation) OVER (PARTITION BY f.City_ID ORDER BY STR_TO_DATE(f.Month, '%b-%y')) AS prev_month_circulation,
        (f.Net_Circulation - LAG(f.Net_Circulation) OVER (PARTITION BY f.City_ID ORDER BY STR_TO_DATE(f.Month, '%b-%y'))) AS circulation_change
    FROM fact_print_sales f
    JOIN dim_city d ON f.City_ID = d.city_id
    WHERE STR_TO_DATE(f.Month, '%b-%y') BETWEEN STR_TO_DATE('Jan-2019', '%b-%Y') AND STR_TO_DATE('Dec-2024', '%b-%Y')
)

SELECT city_name, DATE_FORMAT(month_date, '%Y-%m') AS month, Net_Circulation
FROM MonthlyCirculationChange
WHERE circulation_change < 0
ORDER BY circulation_change ASC
LIMIT 3;

