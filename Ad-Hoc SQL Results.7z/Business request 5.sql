WITH EditionCityMap AS (
    SELECT edition_ID, City_ID FROM fact_print_sales GROUP BY edition_ID, City_ID
),
YearlyCityAdRevenue AS (
SELECT
	m.City_ID,
	d.city AS city,
	LEFT(f.quarter, 4) AS year,
	SUM(f.ad_revenue_inr) AS yearly_ad_revenue
FROM fact_ad_revenue f
JOIN EditionCityMap m ON f.edition_id = m.edition_ID
JOIN dim_city d ON m.City_ID = d.city_id
WHERE LEFT(f.quarter, 4) BETWEEN '2019' AND '2024'
GROUP BY m.City_ID, d.city, year
),
YearlyCityPrint AS (
SELECT
    City_ID,
    SUM(Net_Circulation) AS yearly_net_circulation,
    CONCAT('20', SUBSTRING_INDEX(Month, '-', -1)) AS year
FROM fact_print_sales
WHERE SUBSTRING_INDEX(Month, '-', -1) BETWEEN '19' AND '24'
GROUP BY City_ID, year
),
DeclineCheck AS (
SELECT
	p.City_ID,
	c.city,
	p.year,
	p.yearly_net_circulation,
	a.yearly_ad_revenue,
	CASE WHEN p.yearly_net_circulation < LAG(p.yearly_net_circulation) OVER (PARTITION BY p.City_ID ORDER BY p.year) THEN 'Yes' ELSE 'No' END AS is_declining_print,
	CASE WHEN a.yearly_ad_revenue < LAG(a.yearly_ad_revenue) OVER (PARTITION BY a.City_ID ORDER BY a.year) THEN 'Yes' ELSE 'No' END AS is_declining_ad_revenue
FROM YearlyCityPrint p
JOIN YearlyCityAdRevenue a ON p.City_ID = a.City_ID AND p.year = a.year
JOIN dim_city c ON p.City_ID = c.city_id
)
SELECT
    city,
    year,
    yearly_net_circulation,
    yearly_ad_revenue,
    is_declining_print,
    is_declining_ad_revenue,
    CASE
        WHEN is_declining_print = 'Yes' AND is_declining_ad_revenue = 'Yes' THEN 'Yes' ELSE 'No'
    END AS is_declining_both
FROM DeclineCheck
ORDER BY city, year;

