WITH YearlyCategoryRevenue AS (
    SELECT
        LEFT(fa.quarter, 4) AS year,
        dac.category_group,
        SUM(fa.ad_revenue_inr) AS category_revenue
    FROM fact_ad_revenue fa
    JOIN dim_ad_category dac ON fa.ad_category = dac.ad_category_id
    GROUP BY year, dac.category_group
),
YearlyTotalRevenue AS (
    SELECT
        year,
        SUM(category_revenue) AS total_revenue_year
    FROM YearlyCategoryRevenue
    GROUP BY year
),
CategoryRevenuePct AS (
    SELECT
        ycr.year,
        ycr.category_group AS category_name,
        ycr.category_revenue,
        ytr.total_revenue_year,
        ROUND((ycr.category_revenue / ytr.total_revenue_year) * 100, 2) AS pct_of_year_total
    FROM YearlyCategoryRevenue ycr
    JOIN YearlyTotalRevenue ytr ON ycr.year = ytr.year
)
SELECT
    year,
    category_name,
    category_revenue,
    total_revenue_year,
    pct_of_year_total
FROM CategoryRevenuePct
WHERE pct_of_year_total > 0
ORDER BY year, pct_of_year_total DESC;
