WITH InternetRates2021 AS (
    SELECT
        city_id,
        MAX(CASE WHEN quarter = '2021-Q1' THEN internet_penetration ELSE NULL END) AS internet_rate_q1_2021,
        MAX(CASE WHEN quarter = '2021-Q4' THEN internet_penetration ELSE NULL END) AS internet_rate_q4_2021
    FROM fact_city_readiness
    WHERE quarter IN ('2021-Q1', '2021-Q4')
    GROUP BY city_id
),
InternetGrowth AS (
    SELECT
        icr.city_id,
        d.city AS city_name,
        icr.internet_rate_q1_2021,
        icr.internet_rate_q4_2021,
        icr.internet_rate_q4_2021 - icr.internet_rate_q1_2021 AS delta_internet_rate
    FROM InternetRates2021 icr
    JOIN dim_city d ON icr.city_id = d.city_id
)

SELECT
    city_name,
    internet_rate_q1_2021,
    internet_rate_q4_2021,
    delta_internet_rate
FROM InternetGrowth
ORDER BY delta_internet_rate DESC
LIMIT 1;



