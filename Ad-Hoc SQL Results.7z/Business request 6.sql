WITH Readiness2021 AS (
    SELECT
        city_id,
        AVG((smartphone_penetration + internet_penetration + literacy_rate) / 3) AS readiness_score_2021
    FROM fact_city_readiness
    WHERE quarter LIKE '2021-Q%' -- Use all quarters or latest data for readiness
    GROUP BY city_id
),
PilotEngagement2021 AS (
    SELECT
        city_id,
        SUM(users_reached) AS engagement_metric_2021
    FROM fact_digital_pilot
    WHERE launch_month LIKE '2021-%'
    GROUP BY city_id
),
Ranked AS (
    SELECT
        d.city AS city_name,
        r.readiness_score_2021,
        p.engagement_metric_2021,
        RANK() OVER (ORDER BY r.readiness_score_2021 DESC) AS readiness_rank_desc,
        RANK() OVER (ORDER BY p.engagement_metric_2021 ASC) AS engagement_rank_asc
    FROM Readiness2021 r
    JOIN PilotEngagement2021 p ON r.city_id = p.city_id
    JOIN dim_city d ON r.city_id = d.city_id
)
SELECT
    city_name,
    readiness_score_2021,
    engagement_metric_2021,
    readiness_rank_desc,
    engagement_rank_asc,
    CASE WHEN readiness_rank_desc = 1 AND engagement_rank_asc <= 3 THEN 'Yes' ELSE 'No' END AS is_outlier
FROM Ranked
ORDER BY readiness_rank_desc
LIMIT 1;
