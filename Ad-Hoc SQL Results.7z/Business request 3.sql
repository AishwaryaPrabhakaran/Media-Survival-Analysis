WITH Circulation2024 AS (
    SELECT
        f.City_ID,
        d.city AS city_name,
        SUM(f.Copies_Sold + f.copies_returned) AS copies_printed_2024,
        SUM(f.Net_Circulation) AS net_circulation_2024
    FROM fact_print_sales f
    JOIN dim_city d ON f.City_ID = d.city_id
    WHERE f.Month LIKE '%-24'   -- Filter for the year "2024"
    GROUP BY f.City_ID, d.city
),
EfficiencyScores AS (
    SELECT
        city_name,
        copies_printed_2024,
        net_circulation_2024,
        ROUND(net_circulation_2024 / copies_printed_2024, 4) AS efficiency_ratio
    FROM Circulation2024
    WHERE copies_printed_2024 > 0   -- Avoid division by zero
)

SELECT
    city_name,
    copies_printed_2024,
    net_circulation_2024,
    efficiency_ratio,
    RANK() OVER (ORDER BY efficiency_ratio DESC) AS efficiency_rank_2024
FROM EfficiencyScores
ORDER BY efficiency_rank_2024
LIMIT 5;


    
    
    
    
    